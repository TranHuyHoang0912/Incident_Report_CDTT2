import React, { useState, useEffect } from "react";
import {
  Box,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TableContainer,
  Button,
  Pagination,
  TextField,
  InputAdornment,
  Dialog,
  DialogTitle,
  DialogContent,
  MenuItem,
  Alert,
  CircularProgress,
} from "@mui/material";
import AddIcon from "@mui/icons-material/Add";
import SearchIcon from "@mui/icons-material/Search";
import axios from "../../utils/axios";
import Rating from "@mui/material/Rating";

const pageSize = 8;

const IncidentList = () => {
  const [incidents, setIncidents] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [openDialog, setOpenDialog] = useState(false);

  // Tạo sự cố - state cho form
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [roomId, setRoomId] = useState("");
  const [incidentTypeId, setIncidentTypeId] = useState("");
  const [rooms, setRooms] = useState([]);
  const [incidentTypes, setIncidentTypes] = useState([]);
  const [loadingRooms, setLoadingRooms] = useState(true);
  const [loadingIncidentTypes, setLoadingIncidentTypes] = useState(true);
  const [formError, setFormError] = useState("");
  const [formLoading, setFormLoading] = useState(false);
  const [openRatingDialog, setOpenRatingDialog] = useState(false);
  const [ratingIncident, setRatingIncident] = useState(null); // incident chọn đánh giá
  const [staffRating, setStaffRating] = useState(0);
  const [staffComment, setStaffComment] = useState("");
  const [ratingLoading, setRatingLoading] = useState(false);
  const [ratingError, setRatingError] = useState("");
  // Lấy danh sách phòng
  useEffect(() => {
    const fetchRooms = async () => {
      setLoadingRooms(true);
      try {
        const res = await axios.get("/rooms", {
          params: { take: 100, skip: 0 },
        });
        setRooms(res.data.data || []);
      } catch (err) {
        setRooms([]);
      } finally {
        setLoadingRooms(false);
      }
    };
    if (openDialog) fetchRooms();
  }, [openDialog]);

  // Lấy danh sách loại sự cố
  useEffect(() => {
    const fetchIncidentTypes = async () => {
      setLoadingIncidentTypes(true);
      try {
        const res = await axios.get("/incident-types");
        setIncidentTypes(Array.isArray(res.data) ? res.data : []);
      } catch (err) {
        setIncidentTypes([]);
      } finally {
        setLoadingIncidentTypes(false);
      }
    };
    if (openDialog) fetchIncidentTypes();
  }, [openDialog]);

  // Lấy danh sách sự cố
  const fetchIncidents = async () => {
    const res = await axios.get("/incidents", {
      params: {
        take: pageSize,
        skip: (page - 1) * pageSize,
        search,
      },
    });
    setIncidents(res.data.data || []);
    setTotal(res.data.total || 0);
  };

  useEffect(() => {
    fetchIncidents();
  }, [page, search]);

  // Xử lý tạo mới sự cố
  const handleCreate = async (e) => {
    e.preventDefault();
    setFormError("");
    setFormLoading(true);
    try {
      await axios.post("/incidents", {
        title,
        description,
        roomId: Number(roomId),
        incidentTypeId,
      });
      setOpenDialog(false);
      setTitle("");
      setDescription("");
      setRoomId("");
      setIncidentTypeId("");
      fetchIncidents();
    } catch (err) {
      setFormError("Không tạo được sự cố. Kiểm tra lại dữ liệu.");
    } finally {
      setFormLoading(false);
    }
  };
  const handleOpenRatingDialog = (incident) => {
    setRatingIncident(incident);
    setStaffRating(0);
    setStaffComment("");
    setRatingError("");
    setOpenRatingDialog(true);
  };
  const handleSubmitRating = async (e) => {
    e.preventDefault();
    setRatingLoading(true);
    setRatingError("");
    try {
      await axios.post("/staff-ratings", {
        incidentId: ratingIncident.incidentId,
        staffId: ratingIncident.staffId,
        rating: staffRating,
        comment: staffComment,
      });
      setOpenRatingDialog(false);
      fetchIncidents(); // load lại dữ liệu
    } catch (err) {
      setRatingError(
        err?.response?.data?.message?.[0] ||
          err?.response?.data?.message ||
          "Không gửi được đánh giá."
      );
    } finally {
      setRatingLoading(false);
    }
  };

  return (
    <Paper sx={{ p: 3 }}>
      <Box
        display="flex"
        justifyContent="space-between"
        alignItems="center"
        mb={2}
      >
        <Typography variant="h6">Danh sách sự cố của bạn</Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={() => setOpenDialog(true)}
        >
          Tạo sự cố mới
        </Button>
      </Box>
      <Box mb={2}>
        <TextField
          size="small"
          placeholder="Tìm kiếm sự cố"
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            setPage(1);
          }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon />
              </InputAdornment>
            ),
          }}
        />
      </Box>
      <TableContainer>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>STT</TableCell>
              <TableCell>Tiêu đề</TableCell>
              <TableCell>Phòng</TableCell>
              <TableCell>Loại sự cố</TableCell>
              <TableCell>Trạng thái</TableCell>
              <TableCell>Ngày tạo</TableCell>
              <TableCell>Đánh giá</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {incidents.map((item, idx) => (
              <TableRow key={item.incidentId}>
                <TableCell>{(page - 1) * pageSize + idx + 1}</TableCell>
                <TableCell>{item.title}</TableCell>
                <TableCell>{item.room?.name || ""}</TableCell>
                <TableCell>{item.incidentType?.name || ""}</TableCell>
                <TableCell>{item.status}</TableCell>
                <TableCell>
                  {new Date(item.createdAt).toLocaleString()}
                </TableCell>
                <TableCell>
                  {item.status === "resolved" ? (
                    item.staffRating ? (
                      <Box>
                        <Rating
                          value={item.staffRating.rating}
                          readOnly
                          size="small"
                        />
                        <Typography variant="body2" sx={{ mt: 0.5 }}>
                          {item.staffRating.comment}
                        </Typography>
                      </Box>
                    ) : (
                      <Button
                        size="small"
                        variant="outlined"
                        onClick={() => handleOpenRatingDialog(item)}
                      >
                        Đánh giá
                      </Button>
                    )
                  ) : (
                    <Typography variant="body2" color="text.secondary">
                      -
                    </Typography>
                  )}
                </TableCell>
              </TableRow>
            ))}
            {incidents.length === 0 && (
              <TableRow>
                <TableCell colSpan={6} align="center">
                  Không có dữ liệu
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
      <Box mt={2} display="flex" justifyContent="center">
        <Pagination
          count={Math.ceil(total / pageSize)}
          page={page}
          onChange={(e, val) => setPage(val)}
        />
      </Box>

      {/* Dialog tạo sự cố mới */}
      <Dialog
        open={openDialog}
        onClose={() => setOpenDialog(false)}
        maxWidth="xs"
        fullWidth
      >
        <DialogTitle>Tạo sự cố mới</DialogTitle>
        <DialogContent>
          {formError && <Alert severity="error">{formError}</Alert>}
          <form onSubmit={handleCreate}>
            <TextField
              label="Tiêu đề"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              fullWidth
              required
              margin="normal"
            />
            <TextField
              label="Mô tả"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              fullWidth
              multiline
              rows={3}
              margin="normal"
            />
            <TextField
              select
              label="Phòng"
              value={roomId}
              onChange={(e) => setRoomId(e.target.value)}
              fullWidth
              required
              margin="normal"
              disabled={loadingRooms}
            >
              {loadingRooms ? (
                <MenuItem value="">
                  <CircularProgress size={18} sx={{ mr: 1 }} /> Đang tải
                  phòng...
                </MenuItem>
              ) : rooms.length === 0 ? (
                <MenuItem value="">Không có phòng</MenuItem>
              ) : (
                rooms.map((room) => (
                  <MenuItem key={room.roomId} value={room.roomId}>
                    {room.name}
                  </MenuItem>
                ))
              )}
            </TextField>
            <TextField
              select
              label="Loại sự cố"
              value={incidentTypeId}
              onChange={(e) => setIncidentTypeId(e.target.value)}
              fullWidth
              required
              margin="normal"
              disabled={loadingIncidentTypes}
            >
              {loadingIncidentTypes ? (
                <MenuItem value="">
                  <CircularProgress size={18} sx={{ mr: 1 }} /> Đang tải loại sự
                  cố...
                </MenuItem>
              ) : incidentTypes.length === 0 ? (
                <MenuItem value="">Không có loại sự cố</MenuItem>
              ) : (
                incidentTypes.map((type) => (
                  <MenuItem
                    key={type.incidentTypeId}
                    value={type.incidentTypeId}
                  >
                    {type.name}
                  </MenuItem>
                ))
              )}
            </TextField>
            <Button
              type="submit"
              variant="contained"
              sx={{ mt: 2 }}
              fullWidth
              disabled={formLoading}
            >
              {formLoading ? <CircularProgress size={22} /> : "Tạo sự cố"}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
      <Dialog
        open={openRatingDialog}
        onClose={() => setOpenRatingDialog(false)}
        maxWidth="xs"
        fullWidth
      >
        <DialogTitle>Đánh giá nhân viên xử lý</DialogTitle>
        <DialogContent>
          {ratingError && <Alert severity="error">{ratingError}</Alert>}
          <form onSubmit={handleSubmitRating}>
            <Box my={2}>
              <Typography>Chọn số sao:</Typography>
              <Rating
                value={staffRating}
                onChange={(_, newValue) => setStaffRating(newValue)}
                size="large"
                required
              />
            </Box>
            <TextField
              label="Nhận xét (tuỳ chọn)"
              value={staffComment}
              onChange={(e) => setStaffComment(e.target.value)}
              fullWidth
              margin="normal"
              multiline
              rows={3}
            />
            <Button
              type="submit"
              variant="contained"
              sx={{ mt: 2 }}
              fullWidth
              disabled={ratingLoading || !staffRating}
            >
              {ratingLoading ? <CircularProgress size={22} /> : "Gửi đánh giá"}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </Paper>
  );
};

export default IncidentList;
