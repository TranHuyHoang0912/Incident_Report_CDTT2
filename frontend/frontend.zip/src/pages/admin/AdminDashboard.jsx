// src/pages/admin/AdminDashboard.jsx
import React from "react";
import { Typography, Box, Paper } from "@mui/material";
import axios from '../../utils/axios'; 

const AdminDashboard = () => (
  <Box sx={{ textAlign: "center", mt: 6 }}>
    <Paper elevation={2} sx={{ p: 4, maxWidth: 600, mx: "auto" }}>
      <Typography variant="h4" fontWeight={700} mb={2}>
        Admin Dashboard
      </Typography>
      <Typography mb={2}>
        Chào mừng bạn đến trang quản trị!
      </Typography>
      <Typography variant="body1">
        Hãy chọn chức năng quản lý ở menu bên trái.<br />
        Sau này bạn có thể thêm thống kê tổng quát, biểu đồ hoặc thông tin hệ thống ở đây.
      </Typography>
    </Paper>
  </Box>
);

export default AdminDashboard;
