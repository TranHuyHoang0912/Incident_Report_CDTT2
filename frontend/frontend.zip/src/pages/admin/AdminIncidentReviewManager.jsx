import React, { useEffect, useState } from "react";
import {
  Box, Typography, Paper, Table, TableBody, TableCell, TableHead, TableRow, TableContainer,
  Pagination, TextField, InputAdornment
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import axios from "../../utils/axios";

const pageSize = 8;

const AdminIncidentReviewManager = () => {
  const [reviews, setReviews] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');

  const fetchReviews = async () => {
    const res = await axios.get('/staff-ratings', { params: { take: pageSize, skip: (page - 1) * pageSize, search } });
    setReviews(res.data.data || []);
    setTotal(res.data.total || 0);
  };

  useEffect(() => { fetchReviews(); }, [page, search]);

  return (
    <Paper sx={{ p: 3 }}>
      <Typography variant="h6" mb={2}>Quản lý đánh giá sự cố</Typography>
      <Box mb={2}>
        <TextField
          size="small"
          placeholder="Tìm kiếm đánh giá"
          value={search}
          onChange={e => { setSearch(e.target.value); setPage(1); }}
          InputProps={{
            startAdornment: <InputAdornment position="start"><SearchIcon /></InputAdornment>
          }}
        />
      </Box>
      <TableContainer>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>STT</TableCell>
              <TableCell>Người đánh giá</TableCell>
              <TableCell>Sự cố</TableCell>
              <TableCell>Nội dung</TableCell>
              <TableCell>Điểm</TableCell>
              <TableCell>Ngày đánh giá</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {reviews.map((review, idx) => (
              <TableRow key={review.reviewId}>
                <TableCell>{(page - 1) * pageSize + idx + 1}</TableCell>
                <TableCell>{review.user?.username || review.userId}</TableCell>
                <TableCell>{review.incident?.title || review.incidentId}</TableCell>
                <TableCell>{review.comment}</TableCell>
                <TableCell>{review.rating}</TableCell>
                <TableCell>{new Date(review.createdAt).toLocaleString('vi-VN')}</TableCell>
              </TableRow>
            ))}
            {reviews.length === 0 && (
              <TableRow>
                <TableCell colSpan={6} align="center">Không có dữ liệu</TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
      <Box mt={2} display="flex" justifyContent="center">
        <Pagination count={Math.ceil(total / pageSize)} page={page} onChange={(e, val) => setPage(val)} />
      </Box>
    </Paper>
  );
};

export default AdminIncidentReviewManager;
