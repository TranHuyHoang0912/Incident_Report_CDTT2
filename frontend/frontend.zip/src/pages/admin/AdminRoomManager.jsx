import React, { useEffect, useState } from "react";
import {
  Box,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TableContainer,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  TextField,
  Pagination,
  InputAdornment,
} from "@mui/material";
import AddIcon from "@mui/icons-material/Add";
import SearchIcon from "@mui/icons-material/Search";
import axios from "../../utils/axios";
import { Select, MenuItem, FormControl, InputLabel } from "@mui/material";
import ArrowUpwardIcon from "@mui/icons-material/ArrowUpward";
import ArrowDownwardIcon from "@mui/icons-material/ArrowDownward";

const pageSize = 8;

const AdminRoomManager = () => {
  const [rooms, setRooms] = useState([]);
  const [total, setTotal] = useState(0);
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");

  // const [order, setOrder] = useState('asc'); // Thứ tự sắp xếp: asc/desc
  const [order, setOrder] = useState("asc"); // asc/desc
  const [sortBy, setSortBy] = useState("name"); // name/description

  const fetchRooms = async () => {
    const res = await axios.get("/rooms", {
      params: {
        take: pageSize,
        skip: (page - 1) * pageSize,
        search,
        order,
        sortBy,
      },
    });
    setRooms(res.data.data || []);
    setTotal(res.data.total || 0);
  };
  useEffect(() => {
    fetchRooms();
  }, [page, search, order, sortBy]);

  useEffect(() => {
    fetchRooms();
  }, [page, search, order]);

  const handleSort = (column) => {
    if (sortBy === column) {
      setOrder(order === "asc" ? "desc" : "asc");
    } else {
      setSortBy(column);
      setOrder("asc");
    }
    setPage(1); // reset về trang 1
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    await axios.post("/rooms", { name, description });
    setOpen(false);
    setName("");
    setDescription("");
    fetchRooms();
  };

  return (
    <Paper sx={{ p: 3 }}>
      <Box
        display="flex"
        justifyContent="space-between"
        alignItems="center"
        mb={2}
      >
        <Typography variant="h6">Quản lý phòng</Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={() => setOpen(true)}
        >
          Tạo phòng mới
        </Button>
      </Box>
      <Box mb={2} display="flex" gap={2}>
        <TextField
          size="small"
          placeholder="Tìm kiếm phòng"
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            setPage(1);
          }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon />
              </InputAdornment>
            ),
          }}
        />
      </Box>
      <TableContainer>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>STT</TableCell>
              <TableCell
                sx={{ cursor: "pointer", userSelect: "none" }}
                onClick={() => handleSort("name")}
              >
                Tên phòng
                {sortBy === "name" &&
                  (order === "asc" ? (
                    <ArrowUpwardIcon
                      fontSize="small"
                      sx={{ verticalAlign: "middle" }}
                    />
                  ) : (
                    <ArrowDownwardIcon
                      fontSize="small"
                      sx={{ verticalAlign: "middle" }}
                    />
                  ))}
              </TableCell>
              <TableCell
                sx={{ cursor: "pointer", userSelect: "none" }}
                onClick={() => handleSort("description")}
              >
                Ghi chú
                {sortBy === "description" &&
                  (order === "asc" ? (
                    <ArrowUpwardIcon
                      fontSize="small"
                      sx={{ verticalAlign: "middle" }}
                    />
                  ) : (
                    <ArrowDownwardIcon
                      fontSize="small"
                      sx={{ verticalAlign: "middle" }}
                    />
                  ))}
              </TableCell>
            </TableRow>
          </TableHead>

          <TableBody>
            {rooms.map((room, idx) => (
              <TableRow key={room.roomId}>
                <TableCell>{(page - 1) * pageSize + idx + 1}</TableCell>
                <TableCell>{room.name}</TableCell>
                <TableCell>{room.description}</TableCell>
              </TableRow>
            ))}
            {rooms.length === 0 && (
              <TableRow>
                <TableCell colSpan={3} align="center">
                  Không có dữ liệu
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
      <Box mt={2} display="flex" justifyContent="center">
        <Pagination
          count={Math.ceil(total / pageSize)}
          page={page}
          onChange={(e, val) => setPage(val)}
        />
      </Box>

      {/* Form tạo mới phòng */}
      <Dialog
        open={open}
        onClose={() => setOpen(false)}
        maxWidth="xs"
        fullWidth
      >
        <DialogTitle>Tạo phòng mới</DialogTitle>
        <DialogContent>
          <form onSubmit={handleCreate}>
            <TextField
              label="Tên phòng"
              value={name}
              onChange={(e) => setName(e.target.value)}
              fullWidth
              required
              margin="normal"
            />
            <TextField
              label="Ghi chú"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              fullWidth
              margin="normal"
            />
            <Button type="submit" variant="contained" sx={{ mt: 2 }} fullWidth>
              Tạo phòng
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </Paper>
  );
};

export default AdminRoomManager;
