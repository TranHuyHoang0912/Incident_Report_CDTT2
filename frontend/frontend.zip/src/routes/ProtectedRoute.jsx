import React, { useEffect, useState } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import axios from '../utils/axios';
import { Alert, Container, CircularProgress } from '@mui/material';

const ProtectedRoute = ({ children }) => {
  const [isValid, setIsValid] = useState(null);
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const checkToken = async () => {
      try {
        await axios.get('/auth/me');
        setIsValid(true);
      } catch (err) {
        // Token hết hạn hoặc bị vô hiệu → logout
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        setErrorMessage('Phiên đăng nhập không còn hợp lệ!');
        setIsValid(false);
        setTimeout(() => {
          navigate('/login', { replace: true });
        }, 2000);
      }
    };

    checkToken();
  }, [navigate]);

  if (isValid === null) {
    return (
      <Container sx={{ mt: 10, textAlign: 'center' }}>
        <CircularProgress />
      </Container>
    );
  }

  if (!isValid) {
    return (
      <Container sx={{ mt: 10 }}>
        <Alert severity="error">{errorMessage}</Alert>
      </Container>
    );
  }

  return children;
};

export default ProtectedRoute;
