import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from "./pages/Login";
import ProtectedRoute from "./routes/ProtectedRoute";
import MainLayout from "./layouts/MainLayout";
import AdminLayout from "./layouts/AdminLayout";
import AdminRoomManager from "./pages/admin/AdminRoomManager";
import AdminIncidentReviewManager from "./pages/admin/AdminIncidentReviewManager";
import AdminUserManager from "./pages/admin/AdminUserManager";
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminIncidentManager from "./pages/admin/AdminIncidentManager";
import IncidentList from "./pages/user/IncidentList";
// import IncidentCreate from "./pages/user/IncidentCreate";
import ChangePassword from "./pages/user/ChangePassword";
import RoomList from "./pages/user/RoomList";
import AdminIncidentTypeManager from "./pages/admin/AdminIncidentTypeManager";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route
          path="/admin/*"
          element={
            <ProtectedRoute requiredRole="ADMIN">
              <AdminLayout />
            </ProtectedRoute>
          }
        >
          <Route path="dashboard" element={<AdminDashboard />} />
          <Route
            path="staff-ratings"
            element={<AdminIncidentReviewManager />}
          />
          <Route path="rooms" element={<AdminRoomManager />} />
          <Route path="users" element={<AdminUserManager />} />
          <Route path="incidents" element={<AdminIncidentManager />} />
          <Route path="incident-types" element={<AdminIncidentTypeManager />} />
        </Route>

        <Route
          path="/user/*"
          element={
            <ProtectedRoute>
              <MainLayout />
            </ProtectedRoute>
          }
        >
          <Route path="incidents" element={<IncidentList />} />
          {/* <Route path="incidents/create" element={<IncidentCreate />} /> */}
          <Route path="change-password" element={<ChangePassword />} />
          <Route path="rooms" element={<RoomList />} />
          {/* <Route path="/change-password" element={<ChangePasswordForm />} /> */}
        </Route>

        <Route path="*" element={<Login />} />
      </Routes>
    </BrowserRouter>
  );
}
export default App;
